// server.js
// (Full code inserted here)
